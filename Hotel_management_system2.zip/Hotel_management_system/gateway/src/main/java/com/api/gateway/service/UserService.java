//package com.api.gateway.service;
//import com.api.gateway.entity.User;
//import com.api.gateway.repository.UserRepository;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import java.util.Arrays;
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class UserService {
//
//    private final UserRepository userRepository;
//    private final PasswordEncoder passwordEncoder;
//
//    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
//        this.userRepository = userRepository;
//        this.passwordEncoder = passwordEncoder;
//    }
//
//    public Optional<User> findByUsername(String username) {
//        return userRepository.findByUsername(username);
//    }
//
//    public List<String> getUserRoles(User user) {
//        return Arrays.asList(user.getRoles().split(","));
//    }
//
//    // Optional: Method to create a user
//    public User createUser(String username, String password, String roles) {
//        User user = new User();
//        user.setUsername(username);
//        user.setPassword(passwordEncoder.encode(password));
//        user.setRoles(roles);
//        return userRepository.save(user);
//    }
//}
