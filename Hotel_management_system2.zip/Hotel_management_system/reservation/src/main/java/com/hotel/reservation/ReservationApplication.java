package com.hotel.reservation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class ReservationApplication {

	private static final Logger logger = LoggerFactory.getLogger(ReservationApplication.class);


	public static void main(String[] args) {
		SpringApplication.run(ReservationApplication.class, args);

		logger.info("Reservation started successfully on port 8081");

	}

}
