package com.hotel.staff_service.dto;

import lombok.Data;

@Data
public class RoomDTO {
    private Long id;
    private String roomType;
    private String status;
}
