package com.hotel.guest_service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class GuestServiceApplication {

	private static final Logger logger = LoggerFactory.getLogger(GuestServiceApplication.class);


	public static void main(String[] args) {
		SpringApplication.run(GuestServiceApplication.class, args);

		logger.info("GuestService started successfully on port 8082");

	}

}
